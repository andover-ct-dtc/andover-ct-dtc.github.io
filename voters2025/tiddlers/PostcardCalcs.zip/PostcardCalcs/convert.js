const voters = require('./votersWOdtc.json')
// const voters = require('./voters.json')
const donations = require('./donationsFocused.json')
const committees = Object.fromEntries(require('./committees.json').map(c => [c.caption, c]))
const addresses = require('./addressesWOdtc.json')
//const addresses = require('./addresses.json')

const add = (a, b) => a + b
const mean = (xs) => xs.reduce(add, 0) / (xs.length || 1)
const mapObj = (fn) => (o) => Object.fromEntries(
  Object.entries(o).map(([k, v]) => [k, fn(v)])
)  
const groupBy = (fn, k) => (xs) => xs.reduce(
  (a, x) => ((k = fn(x)), (a[k] = a[k] || []), (a[k].push(x)), a),
  {}
)

const addPoints = (prop, name, min, max) => (xs) => {
  const sorted = [...xs].sort((a, b) => a[prop] - b[prop]).map((x, i) => ({...x, idx: i + 1}))
  const grouped = groupBy (x => String(x[prop])) (sorted)
  const scored = Object.values(grouped).flatMap ((group, _, __, avg = mean(group.map(item => item.idx))) => {
    return group .map (({idx, ...rest}) => ({...rest, [name] : avg}))
  })
  const m = (max - min) / (scored.at(-1)[name] - scored.at(0)[name]), 
    a = scored.at(0)[name],
    b = min - m
  return scored.map(({[name]: rank, ...rest}) => ({...rest, [name]: m * (rank - a) + b}))
}


const donationsFocusedLiberal = donations.filter(d => committees[d['committee-name']].persuasion == "Liberal")

// console.log(JSON.stringify(donationsFocusedLiberal, null, 4))


const votersByCapName = Object.fromEntries(
  voters.map(v => [`${v['first-name'].toUpperCase()} ${v['last-name'].toUpperCase()}`, v])
)

// console.log(JSON.stringify(votersByCapName, null, 4)) 

const donationsByVoter = {
  ...Object.fromEntries(voters.map(v => [`${v['first-name'].toUpperCase()} ${v['last-name'].toUpperCase()}`, []])),
  ...groupBy(c => `${c['contributor-first-name'].toUpperCase()} ${c['contributor-last-name'].toUpperCase()}`)(donationsFocusedLiberal)
}

// console.log(JSON.stringify(donationsByVoter, null, 4))

const voterFields = Object.fromEntries(Object.entries(donationsByVoter).flatMap(([capName, donations]) => {
  const voter = votersByCapName[capName]
  if (!voter) {return []}
  const donationCount = donations.length
  const donationTotal = Math.round(100 * donations.reduce((s, d) => s + Number(d['contribution-receipt-amount']), 0)) / 100
  const dncSupport = Number(voter['dnc-dem-party-support'])
  const age = voter.age || 50
  const agePoints = 65 * age - age * age + 3500
  return [[voter.title, {donationCount, donationTotal, dncSupport, agePoints}]]
}))

// console.log(JSON.stringify(voterFields, null, 4))

const votersWithRawPoints = Object.entries(voterFields).map(([name, fields]) => ({name, ...fields}))

// console.log(JSON.stringify(votersWithRawPoints, null, 4))

const withAge = addPoints('agePoints', 'ageScore', 10, 30) (votersWithRawPoints)
const withSupport = addPoints('dncSupport', 'dncScore', 10, 40) (withAge)
const withDonationTotal = addPoints('donationTotal', 'donationTotalScore', 5, 15) (withSupport)
const withDonationCount = addPoints('donationCount', 'donationCountScore', 5, 15) (withDonationTotal)

// console.log(JSON.stringify(withDonationCount, null, 4))

const withCombinedScore = withDonationCount.map(v => ({
  ...v,
  combinedScore: v.ageScore + v.dncScore + v.donationTotalScore + v.donationCountScore
})) .sort((a, b) => b.combinedScore - a.combinedScore)


// console.log(JSON.stringify(withCombinedScore, null, 4))

const scoredVoterNameMap = Object.fromEntries(withCombinedScore.map(
  ({name, ...rest}) => [name, rest]
))

const addressMap = groupBy(v => `Address/${v['address-id']}`)(voters)

// console.log(JSON.stringify(addressMap, null, 4))


const scoredVoterMap = mapObj(vs => vs.map(v => ({title: v.title, ...scoredVoterNameMap[v.title]})).filter(Boolean))(addressMap)

// console.log(JSON.stringify(scoredVoterMap, null, 4))


const completedVoterMap = mapObj(
  voters => ({
    voters,
    addressScore: voters
      .sort((v1, v2) => v2.combinedScore - v1.combinedScore)
      .map(v => v.combinedScore || 0)
      .reduce((a, s, i) => a + s / (i + 1), 0)
      // .reduce((a, b) => a + b, 0)
  })
)(scoredVoterMap)


// console.log(JSON.stringify(completedVoterMap, null, 4))

const sortedAddresses = Object.entries(completedVoterMap)
  .map (([address, obj]) => ({
    address, 
    addressScore: obj.addressScore,
    voters: obj.voters
      .map(({title, ...rest}) => ({voter: title, ...rest}))
      .filter(v => 'combinedScore' in v)
  }))
  .sort((a, b) => b.addressScore - a.addressScore)

// console.log(JSON.stringify(sortedAddresses, null, 4))  

// console.log(JSON.stringify(sortedAddresses.slice(0, 100), null, 4))

console.log(sortedAddresses/*.slice(0, 200)*/.map(a => a.address).join(' '))